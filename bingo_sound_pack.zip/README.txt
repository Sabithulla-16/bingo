BINGO Sound Pack
================

number_call.wav
- Short two-note cue for a called number / ball call.

line_strike.wav
- Ascending three-note chime for a successful line claim/strike.

bingo_victory.wav
- Spoken "BINGO!" with a short celebratory musical sting.
- Play this only when a player (human or bot) reaches five successful line claims
  and the authoritative game engine declares the round winner.

Suggested implementation notes:
- Respect the Audio & Game Settings > Sound Effects toggle for all three sounds.
- Keep haptic feedback separate and controlled by its own setting.
- In multiplayer, play the victory sound for every connected client when the
  authoritative ROUND_COMPLETED / winner event is received.
- Guard against duplicate events so the victory sound plays once per round per client.
- Do not trigger the victory sound merely when a line is completed; only trigger
  it when the full B-I-N-G-O win condition is confirmed.
